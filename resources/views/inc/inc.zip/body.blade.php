<div class="body_area">
    @include('inc.nav')
    @yield('content')
</div>
