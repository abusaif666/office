@include('inc.script')
</body>
</html>
