<header class="admin_header">
    <div class="container">
        <nav class="admin_navbar">
            <div class="navbar_left">
                <i class="dashboardSidebarShowHideBtn fa fa-bars"></i>
                <i class="dashboardSidebarShowHideBtn2 fa fa-bars"></i>
            </div>
            <div class="navbar_right">
                <div class="admin_header_user_wrapper">
                    <div class="admin_user_box">
                        <div class="user_name_first_letter">A</div>
                        <div class="user_name_title">
                            <div class="user_name">Md Mahamudullah Riyadh</div>
                            <div class="user_title">Bangladesh Cricket Board</div>
                        </div>
                        <div class="admin_dropdown_box">
                            <ul>
                                <li><a href=""><i class="fa fa-user"></i> Profile</a></li>
                                <li><a href=""><i class="fa-solid fa-lock"></i> Security</a></li>
                                <li><a href="{{ route('login') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>
